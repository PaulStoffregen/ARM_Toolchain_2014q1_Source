for (int c0 = 2; c0 <= 8; c0 += 2)
  s0(c0);
