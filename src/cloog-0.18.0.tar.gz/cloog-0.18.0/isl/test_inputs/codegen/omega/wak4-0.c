for (int c0 = max(max(max(max(a1, a2), a3), a4), a5); c0 <= min(min(min(min(b5, b4), b3), b2), b1); c0 += 1) {
  s0(c0);
  s1(c0);
}
