for (int c0 = max(-N, -M); c0 <= min(O, N); c0 += 1)
  S1(c0);
