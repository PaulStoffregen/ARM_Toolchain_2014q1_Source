for (int c1 = 2; c1 <= M; c1 += 7)
  S1(c1, (c1 - 2) / 7);
